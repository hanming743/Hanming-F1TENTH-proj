#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

import numpy as np
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped

class WallFollow(Node):
    """ 
    Implement Wall Following on the car
    """
    def __init__(self):
        super().__init__('wall_follow_node')

        lidarscan_topic = '/scan'
        drive_topic = '/drive'

        # TODO: create subscribers and publishers
        # --- ROS interfaces ---
        self.scan_sub = self.create_subscription(
            LaserScan,
            lidarscan_topic,
            self.scan_callback,
            10
        )
        self.drive_pub = self.create_publisher(
            AckermannDriveStamped,
            drive_topic,
            10
        )

        # TODO: set PID gains
        self.kp = 0.6
        self.kd = 0.35
        self.ki = 0.0

        # TODO: store history
        self.integral = 0.0
        self.prev_error = 0.0
        self.error = 0.0

        # TODO: store any necessary values you think you'll need
        # Timing for dt (filled on first callback)
        self.prev_time = None  # use self.get_clock().now() in scan_callback

        # --- Wall-follow parameters ---
        self.desired_dist = 1.0      # meters from left wall (setpoint)
        self.lookahead_dist = 1.0    # meters forward projection (used in get_error math)

        # Angles used for wall geometry (left wall):
        # 90 deg = left, 45 deg = front-left
        self.theta = np.deg2rad(45.0)

        # Steering/speed limits (common in F1TENTH-style sims; adjust if needed)
        self.max_steer = 0.34        # radians
        self.min_speed = 1.0         # m/s
        self.max_speed = 2.5         # m/s

        # Integral anti-windup clamp (optional but recommended)
        self.integral_limit = 2.0

        # Scan metadata (set in scan_callback once we receive a LaserScan)
        self.angle_min = None
        self.angle_max = None
        self.angle_increment = None
        self.range_min = None
        self.range_max = None

    def get_range(self, range_data, angle):
        """
        Simple helper to return the corresponding range measurement at a given angle. Make sure you take care of NaNs and infs.

        Args:
            range_data: single range array from the LiDAR
            angle: between angle_min and angle_max of the LiDAR

        Returns:
            range: range measurement in meters at the given angle

        """

        #TODO: implement

        # haven't received scan metadata, fail safe
        if self.angle_min is None or self.angle_increment is None:
            return float('inf')

        # Convert angle -> index
        idx = int(round((angle - self.angle_min) / self.angle_increment))

        # Clamp to valid bounds
        idx = max(0, min(idx, len(range_data) - 1))

        r = range_data[idx]

        # Handle NaN/inf/invalid readings
        if r is None or not np.isfinite(r) or r <= 0.0:
            return float('inf')

        # clamp to sensor min/max if we have them
        if self.range_min is not None:
            r = max(r, self.range_min)
        if self.range_max is not None:
            r = min(r, self.range_max)

        return float(r)

    def get_error(self, range_data, dist):
        """
        Calculates the error to the wall. Follow the wall to the left (going counter clockwise in the Levine loop). You potentially will need to use get_range()

        Args:
            range_data: single range array from the LiDAR
            dist: desired distance to the wall

        Returns:
            error: calculated error
        """

        #TODO:implement

        # Angles in LiDAR frame (assuming 0 rad is forward, + is CCW/left)
        angle_b = np.deg2rad(-90.0)                 # left
        angle_a = angle_b + self.theta             # front-left (e.g., 45 deg)

        b = self.get_range(range_data, angle_b)
        a = self.get_range(range_data, angle_a)

        # If either measurement is invalid, fail safe: no steering correction
        if not np.isfinite(a) or not np.isfinite(b) or a == float('inf') or b == float('inf'):
            return 0.0

        # Wall geometry (standard F1TENTH wall follow derivation)
        # alpha = angle between car heading and wall
        numerator = a * np.cos(self.theta) - b
        denominator = a * np.sin(self.theta)

        # Avoid division by ~0
        if abs(denominator) < 1e-6:
            return 0.0

        alpha = np.arctan2(numerator, denominator)

        # Current perpendicular distance to wall
        d_current = b * np.cos(alpha)

        # Project forward by lookahead distance
        d_future = d_current + self.lookahead_dist * np.sin(alpha)

        # Error: positive if we are farther than desired (need to steer left toward wall)
        error = dist - d_future
        return float(error)

    def pid_control(self, error):
        """
        Based on the calculated error, publish vehicle control

        Args:
            error: calculated error
            velocity: desired velocity

        Returns:
            None
        """
        angle = 0.0
        # TODO: Use kp, ki & kd to implement a PID controller
        #drive_msg = AckermannDriveStamped()
        # TODO: fill in drive message and publish
        # Time step
        now = self.get_clock().now()
        if self.prev_time is None:
            dt = 0.0
        else:
            dt = (now - self.prev_time).nanoseconds * 1e-9
        self.prev_time = now

        self.error = float(error)

        # Integral
        if dt > 0.0:
            self.integral += self.error * dt
            if self.integral_limit is not None:
                self.integral = float(np.clip(self.integral, -self.integral_limit, self.integral_limit))

        # Derivative
        derivative = (self.error - self.prev_error) / dt if dt > 0.0 else 0.0

        # PID steering
        angle = (self.kp * self.error) + (self.ki * self.integral) + (self.kd * derivative)
        angle = float(np.clip(angle, -self.max_steer, self.max_steer))
        self.prev_error = self.error

        # speed policy
        steer_deg = abs(angle) * 180.0 / np.pi
        if steer_deg < 10.0:
            speed = 1.5
        elif steer_deg < 20.0:
            speed = 1.0
        else:
            speed = 0.5

        drive_msg = AckermannDriveStamped()
        drive_msg.header.stamp = now.to_msg()
        drive_msg.header.frame_id = "base_link"
        drive_msg.drive.steering_angle = angle
        drive_msg.drive.speed = speed

        self.drive_pub.publish(drive_msg)

    def scan_callback(self, msg):
        """
        Callback function for LaserScan messages. Calculate the error and publish the drive message in this function.

        Args:
            msg: Incoming LaserScan message

        Returns:
            None
        """
        #error = 0.0 # TODO: replace with error calculated by get_error()
        #velocity = 0.0 # TODO: calculate desired car velocity based on error
        #self.pid_control(error, velocity) # TODO: actuate the car with PID

        self.angle_min = msg.angle_min
        self.angle_max = msg.angle_max
        self.angle_increment = msg.angle_increment
        self.range_min = msg.range_min
        self.range_max = msg.range_max

        error = self.get_error(msg.ranges, self.desired_dist)
        self.pid_control(error)  # speed handled inside pid_control per spec


def main(args=None):
    rclpy.init(args=args)
    print("WallFollow Initialized")
    wall_follow_node = WallFollow()
    rclpy.spin(wall_follow_node)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    wall_follow_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()