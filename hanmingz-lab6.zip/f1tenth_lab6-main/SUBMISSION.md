# Lab 6: Motion Planing

## Video Link
(FILL ME IN)
https://youtu.be/X6W659DrcgA