#include "rclcpp/rclcpp.hpp"
#include "ackermann_msgs/msg/ackermann_drive_stamped.hpp"

class Relay : public rclcpp::Node {
public:
  Relay() : Node("relay") {
    pub_ = this->create_publisher<ackermann_msgs::msg::AckermannDriveStamped>("/drive_relay", 10);

    sub_ = this->create_subscription<ackermann_msgs::msg::AckermannDriveStamped>(
      "/drive", 10,
      [this](const ackermann_msgs::msg::AckermannDriveStamped::SharedPtr msg) {
        auto out = *msg;
        out.header.stamp = this->get_clock()->now();

        out.drive.speed *= 3.0f;
        out.drive.steering_angle *= 3.0f;

        pub_->publish(out);
      });

    RCLCPP_INFO(this->get_logger(), "relay started (/drive -> /drive_relay).");
  }

private:
  rclcpp::Publisher<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr pub_;
  rclcpp::Subscription<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr sub_;
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Relay>());
  rclcpp::shutdown();
  return 0;
}
