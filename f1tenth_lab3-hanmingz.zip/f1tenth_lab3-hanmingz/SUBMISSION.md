# Lab 3: Wall Following

## YouTube video links
Simulator (individual) : (https://youtu.be/f1DGxO-bmBQ)

Hardware (group) : https://youtu.be/f1DGxO-bmBQ

videos are edited to be in one