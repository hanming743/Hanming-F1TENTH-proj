# Lab 7: mpc

## YouTube video link
[FILL ME IN](https://youtu.be/R_VJSXtR1Bs)
