from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    pkg_share = get_package_share_directory('lab1_pkg')
    params_file = os.path.join(pkg_share, 'config', 'lab1_params.yaml')

    v_arg = DeclareLaunchArgument('v', default_value='1.0')
    d_arg = DeclareLaunchArgument('d', default_value='0.2')

    talker_node = Node(
        package='lab1_pkg',
        executable='talker',        # change if your executable name differs
        name='talker',
        output='screen',
        parameters=[
            params_file,  # baseline from YAML
            {   # optional overrides via launch args
                'v': ParameterValue(LaunchConfiguration('v'), value_type=float),
                'd': ParameterValue(LaunchConfiguration('d'), value_type=float),
            }
        ],
    )

    relay_node = Node(
        package='lab1_pkg',
        executable='relay',         # change if your executable name differs
        name='relay',
        output='screen',
    )

    return LaunchDescription([
        v_arg,
        d_arg,
        talker_node,
        relay_node,
    ])
