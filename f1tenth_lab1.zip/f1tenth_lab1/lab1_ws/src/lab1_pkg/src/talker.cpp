#include <chrono>
#include "rclcpp/rclcpp.hpp"
#include "ackermann_msgs/msg/ackermann_drive_stamped.hpp"

using namespace std::chrono_literals;

class Talker : public rclcpp::Node {
public:
  Talker() : Node("talker") {
    this->declare_parameter<double>("v", 1.0);
    this->declare_parameter<double>("d", 0.2);

    pub_ = this->create_publisher<ackermann_msgs::msg::AckermannDriveStamped>("/drive", 10);

    timer_ = this->create_wall_timer(100ms, [this]() {
      const double v = this->get_parameter("v").as_double();
      const double d = this->get_parameter("d").as_double();

      ackermann_msgs::msg::AckermannDriveStamped msg;
      msg.header.stamp = this->get_clock()->now();
      msg.header.frame_id = "base_link";
      msg.drive.speed = static_cast<float>(v);
      msg.drive.steering_angle = static_cast<float>(d);

      pub_->publish(msg);
    });

    RCLCPP_INFO(this->get_logger(), "talker started (publishing /drive).");
  }

private:
  rclcpp::Publisher<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr pub_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Talker>());
  rclcpp::shutdown();
  return 0;
}
