# Lab 1: Intro to ROS 2

## Written Questions

### Q1: During this assignment, you've probably ran these two following commands at some point: ```source /opt/ros/foxy/setup.bash``` and ```source install/local_setup.bash```. Functionally what is the difference between the two?

Answer: ```source /opt/ros/foxy/setup.bash``` turns on ROS 2 Foxy while ```source install/local_setup.bash``` turns on my workspace. After ```source /opt/ros/foxy/setup.bash```, the terminal knows where the main ROS2 programs and libraries are. After ```source install/local_setup.bash```, my own built is loaded.

### Q2: What does the ```queue_size``` argument control when creating a subscriber or a publisher? How does different ```queue_size``` affect how messages are handled?

Answer: If the node is publishing faster than the subscriber can send out, the extra messages are stored in a buffer until they fill the queue size. At that time, old messages are dropped for the space of new messages. When there are too many messages coming to the subscriber, extra messages will be stored in a buffer until it reach queue_size, then the oldest messages will be dropped. Small queue size can make sure the system has a low delay, but some important messages would be dropped. Big queue sizes would create a lag, on the other hand.

### Q3: Do you have to call ```colcon build``` again after you've changed a launch file in your package? (Hint: consider two cases: calling ```ros2 launch``` in the directory where the launch file is, and calling it when the launch file is installed with the package.)

Answer: If I run launch file from the source folder, there's no need to rebuild. If I run like "ros2 launch lab1_pkg lab1_launch.py", I would need to rebuild if I didn't build with "--symlink-install".
