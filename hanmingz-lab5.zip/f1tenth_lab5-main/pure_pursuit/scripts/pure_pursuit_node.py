#!/usr/bin/env python3
#hm
import csv
import math

import numpy as np
import rclpy
from rclpy.node import Node

from nav_msgs.msg import Odometry
from ackermann_msgs.msg import AckermannDriveStamped

from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
from std_msgs.msg import Header


class PurePursuit(Node):
    """
    Pure Pursuit controller for F1TENTH sim.

    Uses:
      pose topic  : /ego_racecar/odom
      drive topic : /drive
      waypoint csv: x,y columns in map frame
    """

    def __init__(self):
        super().__init__('pure_pursuit_node')

        # Parameters
        self.declare_parameter('waypoints_csv', '/sim_ws/path.csv')
        self.declare_parameter('lookahead_distance', 1.0)
        self.declare_parameter('speed', 1.2)
        self.declare_parameter('max_steering_angle', 0.4189)   # about 24 degrees
        self.declare_parameter('wheelbase', 0.3302)

        self.waypoints_csv = self.get_parameter('waypoints_csv').value
        self.lookahead_distance = float(self.get_parameter('lookahead_distance').value)
        self.speed = float(self.get_parameter('speed').value)
        self.max_steering_angle = float(self.get_parameter('max_steering_angle').value)
        self.wheelbase = float(self.get_parameter('wheelbase').value)

        self.all_waypoints_pub = self.create_publisher(MarkerArray, '/pp/all_waypoints', 10)
        self.target_waypoint_pub = self.create_publisher(Marker, '/pp/target_waypoint', 10)

        # Load waypoints
        self.waypoints = self.load_waypoints(self.waypoints_csv)
        if len(self.waypoints) == 0:
            raise RuntimeError(f'No waypoints loaded from {self.waypoints_csv}')

        self.get_logger().info(f'Loaded {len(self.waypoints)} waypoints from {self.waypoints_csv}')

        # Publisher and subscriber
        self.drive_pub = self.create_publisher(AckermannDriveStamped, '/drive', 10)
        self.pose_sub = self.create_subscription(
            Odometry,
            '/ego_racecar/odom',
            self.pose_callback,
            10
        )

        self.current_waypoint_idx = 0

        self.timer = self.create_timer(0.5, self.publish_all_waypoints)

    def load_waypoints(self, csv_path):
        waypoints = []
        with open(csv_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x = float(row['x'])
                y = float(row['y'])
                waypoints.append([x, y])
        return np.array(waypoints)

    def get_yaw_from_quaternion(self, q):
        """
        Convert quaternion to yaw.
        """
        x = q.x
        y = q.y
        z = q.z
        w = q.w

        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        return math.atan2(siny_cosp, cosy_cosp)

    def find_target_waypoint(self, car_x, car_y):
        """
        Find the first waypoint at least lookahead_distance away from the car.
        Starts searching from current_waypoint_idx to avoid scanning from 0 every time.
        """
        n = len(self.waypoints)

        for i in range(n):
            idx = (self.current_waypoint_idx + i) % n
            wp_x, wp_y = self.waypoints[idx]

            dist = math.hypot(wp_x - car_x, wp_y - car_y)
            if dist >= self.lookahead_distance:
                self.current_waypoint_idx = idx
                return wp_x, wp_y, idx

        # fallback
        wp_x, wp_y = self.waypoints[self.current_waypoint_idx]
        return wp_x, wp_y, self.current_waypoint_idx

    def pose_callback(self, pose_msg):
        # Current pose in map frame
        car_x = pose_msg.pose.pose.position.x
        car_y = pose_msg.pose.pose.position.y
        car_yaw = self.get_yaw_from_quaternion(pose_msg.pose.pose.orientation)

        # Find the current waypoint to track
        goal_x, goal_y, goal_idx = self.find_target_waypoint(car_x, car_y)

        # Publish the current target waypoint in red
        self.publish_target_waypoint(goal_x, goal_y)

        # Transform goal point to vehicle frame
        dx = goal_x - car_x
        dy = goal_y - car_y

        x_goal_vehicle = math.cos(car_yaw) * dx + math.sin(car_yaw) * dy
        y_goal_vehicle = -math.sin(car_yaw) * dx + math.cos(car_yaw) * dy

        # If the point is behind the car, skip ahead a little
        if x_goal_vehicle < 0.0:
            goal_idx = (goal_idx + 1) % len(self.waypoints)
            goal_x, goal_y = self.waypoints[goal_idx]

            # Update the red marker to the corrected target
            self.publish_target_waypoint(goal_x, goal_y)

            dx = goal_x - car_x
            dy = goal_y - car_y
            x_goal_vehicle = math.cos(car_yaw) * dx + math.sin(car_yaw) * dy
            y_goal_vehicle = -math.sin(car_yaw) * dx + math.cos(car_yaw) * dy

        # Calculate curvature / steering angle
        L = math.hypot(x_goal_vehicle, y_goal_vehicle)
        if L < 1e-6:
            return

        curvature = 2.0 * y_goal_vehicle / (L * L)
        steering_angle = math.atan(self.wheelbase * curvature)

        # Limit steering angle
        steering_angle = max(
            -self.max_steering_angle,
            min(self.max_steering_angle, steering_angle)
        )

        # Publish drive message
        drive_msg = AckermannDriveStamped()
        drive_msg.drive.steering_angle = steering_angle
        drive_msg.drive.speed = self.speed
        self.drive_pub.publish(drive_msg)

    def publish_all_waypoints(self):
        marker_array = MarkerArray()

        for idx, (x, y) in enumerate(self.waypoints):
            marker = Marker()
            marker.header = Header()
            marker.header.frame_id = 'map'
            marker.header.stamp = self.get_clock().now().to_msg()

            marker.ns = 'waypoints'
            marker.id = idx
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD

            marker.pose.position.x = float(x)
            marker.pose.position.y = float(y)
            marker.pose.position.z = 0.0
            marker.pose.orientation.w = 1.0

            marker.scale.x = 0.15
            marker.scale.y = 0.15
            marker.scale.z = 0.15

            marker.color.r = 0.0
            marker.color.g = 1.0
            marker.color.b = 0.0
            marker.color.a = 1.0

            marker.lifetime.sec = 0
            marker.lifetime.nanosec = 0
            marker.frame_locked = False

            marker_array.markers.append(marker)

        self.all_waypoints_pub.publish(marker_array)

    def publish_target_waypoint(self, x, y):
        marker = Marker()
        marker.header.frame_id = 'map'
        marker.header.stamp = self.get_clock().now().to_msg()

        marker.ns = 'target_waypoint'
        marker.id = 0
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD

        marker.pose.position.x = float(x)
        marker.pose.position.y = float(y)
        marker.pose.position.z = 0.0
        marker.pose.orientation.w = 1.0

        marker.scale.x = 0.25
        marker.scale.y = 0.25
        marker.scale.z = 0.25

        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0
        marker.color.a = 1.0

        marker.lifetime.sec = 0
        marker.lifetime.nanosec = 0
        marker.frame_locked = False

        self.target_waypoint_pub.publish(marker)

def main(args=None):
    rclpy.init(args=args)
    print("PurePursuit Initialized")
    pure_pursuit_node = PurePursuit()
    rclpy.spin(pure_pursuit_node)

    pure_pursuit_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()