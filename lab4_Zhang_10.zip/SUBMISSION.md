# Lab 4: Follow the Gap

## YouTube video link
https://youtu.be/yPwtJuGZfWk

#failure reasons: when there is a dead-end, increasingly narrow areas, the car doesn't know and can't expect dead end; in addition, when there's a wide opening suddenly occuring near an obstacle, which is a way out, but the car won't notice and will keep going into the narrow dead end. I suppose there should be a perfect bubble size, fov, and clip distance pair for solving this, which I couldn't find.