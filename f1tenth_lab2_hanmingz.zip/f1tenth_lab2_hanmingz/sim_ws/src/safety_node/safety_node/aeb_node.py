#!/usr/bin/env python3
import math
import numpy as np

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from ackermann_msgs.msg import AckermannDriveStamped


class AEBNode(Node):
    def __init__(self):
        super().__init__('aeb_node')

        # tune these later
        self.declare_parameter('ttc_threshold', 0.8)  # seconds
        self.declare_parameter('fov_deg', 20.0)       # +/- degrees in front

        self.ttc_threshold = float(self.get_parameter('ttc_threshold').value)
        self.fov = math.radians(float(self.get_parameter('fov_deg').value))

        self.vx = 0.0

        self.drive_pub = self.create_publisher(AckermannDriveStamped, '/drive', 10)
        self.create_subscription(LaserScan, '/scan', self.scan_cb, 10)
        self.create_subscription(Odometry, '/ego_racecar/odom', self.odom_cb, 10)

        self.get_logger().info('AEB node started.')

    def odom_cb(self, msg: Odometry):
        self.vx = float(msg.twist.twist.linear.x)

    def scan_cb(self, msg: LaserScan):
        if self.vx <= 0.05:
            return

        ranges = np.array(msg.ranges, dtype=np.float32)
        n = ranges.size
        angles = msg.angle_min + np.arange(n) * msg.angle_increment

        # consider only front rays
        front = np.abs(angles) <= self.fov

        # valid ranges only
        valid = np.isfinite(ranges) & (ranges > 0.05)
        mask = front & valid
        if not np.any(mask):
            return

        r = ranges[mask]
        theta = angles[mask]

        # approximate range rate for stationary obstacles
        r_dot = -self.vx * np.cos(theta)

        closing = (-r_dot) > 0.0
        if not np.any(closing):
            return

        ittc = r[closing] / (-r_dot[closing])
        min_ittc = float(np.min(ittc))

        if min_ittc < self.ttc_threshold:
            self.get_logger().warn(f'BRAKE! min iTTC={min_ittc:.3f}s')
            self.publish_brake()

    def publish_brake(self):
        msg = AckermannDriveStamped()
        msg.drive.speed = 0.0
        msg.drive.steering_angle = 0.0
        self.drive_pub.publish(msg)


def main():
    rclpy.init()
    node = AEBNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
