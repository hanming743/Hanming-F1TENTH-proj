#!/usr/bin/env python3
"""
Subscribes:  /scan  (sensor_msgs/LaserScan)
Publishes:   /drive (ackermann_msgs/AckermannDriveStamped)

Implements:
- preprocess_lidar
- closest point + safety bubble
- find_max_gap
- find_best_point
- speed scheduling
"""

import rclpy
from rclpy.node import Node

import numpy as np
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped


class ReactiveFollowGap(Node):
    def __init__(self):
        super().__init__('reactive_follow_gap')

        # Topics
        self.lidarscan_topic = '/scan'
        self.drive_topic = '/drive'

        # ROS interfaces
        self.scan_sub = self.create_subscription(
            LaserScan,
            self.lidarscan_topic,
            self.lidar_callback,
            10
        )
        self.drive_pub = self.create_publisher(
            AckermannDriveStamped,
            self.drive_topic,
            10
        )

        # Tunable parameters
        self.max_range_clip = 2          # meters, clip anything beyond to this
        self.smooth_window = 7             # odd int 
        self.fov_deg = 140.0               
        self.bubble_radius_m = 0.4        # meters safety bubble around closest obstacle
        self.min_valid_range = 0.05        # treat smaller as invalid

        # Steering/speed limits
        self.max_steer = 0.34              # rad
        self.speed_straight = 2
        self.speed_medium = 1
        self.speed_turn = 0.8
        self.speed_hard_turn = 0.4

        # If scan gets fully blocked
        self.failsafe_speed = 0.5

        # Cached scan metadata
        self.angle_min = None
        self.angle_max = None
        self.angle_increment = None
        self.range_min = None
        self.range_max = None

        self.get_logger().info("ReactiveFollowGap initialized (ROS2, Python).")

    # helpers

    def preprocess_lidar(self, ranges: np.ndarray) -> np.ndarray:
        """
        Preprocess LiDAR:
        - replace NaN/inf with 0
        - clip to [0, max_range_clip]
        - smooth with moving average
        - optional: keep only forward FOV (others set to 0)
        """
        proc = np.array(ranges, dtype=np.float32)

        # Replace invalids
        proc[~np.isfinite(proc)] = 0.0
        proc[proc < self.min_valid_range] = 0.0

        # Clip
        proc = np.clip(proc, 0.0, self.max_range_clip)

        # Smooth
        w = int(self.smooth_window)
        if w >= 3:
            if w % 2 == 0:
                w += 1
            kernel = np.ones(w, dtype=np.float32) / float(w)
            proc = np.convolve(proc, kernel, mode='same')

        # Apply forward FOV mask
        if self.angle_min is not None and self.angle_increment is not None:
            half_fov = np.deg2rad(self.fov_deg / 2.0)
            # index for angle 0
            idx_center = int(round((0.0 - self.angle_min) / self.angle_increment))
            idx_center = max(0, min(idx_center, len(proc) - 1))

            # how many indices correspond to half_fov
            half_width = int(round(half_fov / self.angle_increment))
            start = max(0, idx_center - half_width)
            end = min(len(proc) - 1, idx_center + half_width)

            masked = np.zeros_like(proc)
            masked[start:end + 1] = proc[start:end + 1]
            proc = masked

        return proc

    def find_max_gap(self, free_space_ranges: np.ndarray):
        """
        Return (start_i, end_i) for the longest contiguous segment where values > 0.
        If no gap exists, return (None, None).
        """
        arr = free_space_ranges
        n = len(arr)

        best_start = None
        best_end = None
        best_len = 0

        i = 0
        while i < n:
            # skip zeros
            while i < n and arr[i] <= 0.0:
                i += 1
            if i >= n:
                break

            start = i
            while i < n and arr[i] > 0.0:
                i += 1
            end = i - 1

            seg_len = end - start + 1
            if seg_len > best_len:
                best_len = seg_len
                best_start, best_end = start, end

        if best_start is None:
            return None, None
        return best_start, best_end

    def find_best_point(self, start_i: int, end_i: int, ranges: np.ndarray) -> int:
        """
        Pick best point index within [start_i, end_i].
        Better-than-naive scoring:
          score = range - center_bias * |angle|
        This tends to keep you fast and stable.
        """
        if start_i is None or end_i is None or end_i <= start_i:
            return None

        gap = ranges[start_i:end_i + 1]
        if gap.size == 0:
            return None

        # angles for indices
        idxs = np.arange(start_i, end_i + 1)
        angles = self.angle_min + idxs * self.angle_increment

        # scoring: prefer far + near centerline
        center_bias = 0.9  # tune 
        scores = gap - center_bias * np.abs(angles)

        # If all zeros, fail
        if np.all(scores <= 0.0):
            # fallback: midpoint
            return int((start_i + end_i) // 2)

        best_local = int(np.argmax(scores))
        return int(start_i + best_local)

    def _apply_bubble(self, ranges: np.ndarray, closest_idx: int) -> np.ndarray:
        """
        Zero-out points within a bubble around the closest point.
        Bubble size in indices depends on distance and angle_increment.
        """
        arr = ranges.copy()
        d = float(arr[closest_idx])
        if d <= 0.0 or not np.isfinite(d):
            return arr

        # angular half-width that corresponds to bubble radius at distance d:
        # arc length s = d * delta_theta => delta_theta = R / d
        delta_theta = self.bubble_radius_m / max(d, 1e-3)
        bubble_half = int(round(delta_theta / self.angle_increment))

        start = max(0, closest_idx - bubble_half)
        end = min(len(arr) - 1, closest_idx + bubble_half)
        arr[start:end + 1] = 0.0
        return arr

    def _compute_speed(self, steer_angle: float, min_forward: float) -> float:
        """
        Simple speed schedule based on steering magnitude and proximity.
        """
        a = abs(steer_angle)

        # If something is very close in front, slow down
        if min_forward < 0.6:
            return 0.6
        if min_forward < 1.0:
            return 0.9

        if a < np.deg2rad(10):
            return self.speed_straight
        elif a < np.deg2rad(20):
            return self.speed_medium
        elif a < np.deg2rad(28):
            return self.speed_turn
        else:
            return self.speed_hard_turn

    # ROS callback 

    def lidar_callback(self, msg: LaserScan):
        # Cache scan metadata
        self.angle_min = msg.angle_min
        self.angle_max = msg.angle_max
        self.angle_increment = msg.angle_increment
        self.range_min = msg.range_min
        self.range_max = msg.range_max

        raw = np.array(msg.ranges, dtype=np.float32)
        proc = self.preprocess_lidar(raw)

        # If everything is zero, failsafe
        if np.all(proc <= 0.0):
            self._publish_drive(0.0, self.failsafe_speed, msg)
            return

        # 1) Closest point
        nonzero = np.where(proc > 0.0)[0]
        if nonzero.size == 0:
            self._publish_drive(0.0, self.failsafe_speed, msg)
            return

        closest_idx = int(nonzero[np.argmin(proc[nonzero])])

        # 2) Safety bubble
        free = self._apply_bubble(proc, closest_idx)

        # 3) Max gap
        start_i, end_i = self.find_max_gap(free)
        if start_i is None:
            self._publish_drive(0.0, self.failsafe_speed, msg)
            return

        # 4) Best point
        best_idx = self.find_best_point(start_i, end_i, free)
        if best_idx is None:
            self._publish_drive(0.0, self.failsafe_speed, msg)
            return

        # 5) Convert best_idx to steering angle
        target_angle = self.angle_min + best_idx * self.angle_increment
        steer = float(np.clip(target_angle, -self.max_steer, self.max_steer))

        # compute min distance in a small forward cone for speed logic
        min_forward = self._min_forward_distance(proc)

        speed = self._compute_speed(steer, min_forward)
        self._publish_drive(steer, speed, msg)

    def _min_forward_distance(self, proc_ranges: np.ndarray) -> float:
        """
        Min distance in a narrow cone around straight ahead for collision-aware speed.
        """
        if self.angle_min is None or self.angle_increment is None:
            return float('inf')

        idx_center = int(round((0.0 - self.angle_min) / self.angle_increment))
        idx_center = max(0, min(idx_center, len(proc_ranges) - 1))

        cone_deg = 45
        half = int(round(np.deg2rad(cone_deg / 2.0) / self.angle_increment))
        s = max(0, idx_center - half)
        e = min(len(proc_ranges) - 1, idx_center + half)

        cone = proc_ranges[s:e + 1]
        nz = cone[cone > 0.0]
        if nz.size == 0:
            return float('inf')
        return float(np.min(nz))

    def _publish_drive(self, steering_angle: float, speed: float, scan_msg: LaserScan):
        drive_msg = AckermannDriveStamped()
        drive_msg.header.stamp = self.get_clock().now().to_msg()
        drive_msg.header.frame_id = "base_link"
        drive_msg.drive.steering_angle = float(steering_angle)
        drive_msg.drive.speed = float(speed)
        self.drive_pub.publish(drive_msg)


def main(args=None):
    rclpy.init(args=args)
    print("ReactiveFollowGap Initialized")
    node = ReactiveFollowGap()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
