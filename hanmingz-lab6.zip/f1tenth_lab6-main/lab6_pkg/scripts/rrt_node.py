#!/usr/bin/env python3

import csv
import math
import numpy as np

import rclpy
from rclpy.node import Node as ROSNode

from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry, OccupancyGrid
from ackermann_msgs.msg import AckermannDriveStamped
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point


class TreeNode:
    def __init__(self, x=0.0, y=0.0, parent=None, cost=0.0, is_root=False):
        self.x = x
        self.y = y
        self.parent = parent
        self.cost = cost
        self.is_root = is_root


class RRT(ROSNode):
    def __init__(self):
        super().__init__('rrt_node')

        # Parameters
        self.declare_parameter('pose_topic', '/ego_racecar/odom')
        self.declare_parameter('scan_topic', '/scan')
        self.declare_parameter('drive_topic', '/drive')
        self.declare_parameter('local_frame', 'ego_racecar/base_link')
        self.declare_parameter('waypoints_csv', '/sim_ws/path.csv')

        self.declare_parameter('lookahead_distance', 1.2)
        self.declare_parameter('path_lookahead', 1)
        self.declare_parameter('speed', 0.8)
        self.declare_parameter('wheelbase', 0.3302)
        self.declare_parameter('max_steering_angle', 0.4189)

        self.declare_parameter('grid_resolution', 0.05)
        self.declare_parameter('grid_x_min', -1.0)
        self.declare_parameter('grid_x_max', 2.0)
        self.declare_parameter('grid_y_min', -2.0)
        self.declare_parameter('grid_y_max', 2.0)
        self.declare_parameter('robot_radius', 0.12)

        self.declare_parameter('step_size', 0.35)
        self.declare_parameter('goal_tolerance', 0.35)
        self.declare_parameter('max_rrt_iters', 300)
        self.declare_parameter('goal_sample_rate', 0.05)
        self.declare_parameter('min_forward_goal_x', 0.30)

        self.declare_parameter('reuse_path_timeout', 0.5)
        self.declare_parameter('max_subgoal_x', 1.2)

        # New param for goal snapping
        self.declare_parameter('goal_snap_radius', 0.5)

        self.pose_topic = self.get_parameter('pose_topic').value
        self.scan_topic = self.get_parameter('scan_topic').value
        self.drive_topic = self.get_parameter('drive_topic').value
        self.local_frame = self.get_parameter('local_frame').value
        self.waypoints_csv = self.get_parameter('waypoints_csv').value

        self.lookahead_distance = float(self.get_parameter('lookahead_distance').value)
        self.path_lookahead = float(self.get_parameter('path_lookahead').value)
        self.speed = float(self.get_parameter('speed').value)
        self.wheelbase = float(self.get_parameter('wheelbase').value)
        self.max_steering_angle = float(self.get_parameter('max_steering_angle').value)

        self.grid_resolution = float(self.get_parameter('grid_resolution').value)
        self.grid_x_min = float(self.get_parameter('grid_x_min').value)
        self.grid_x_max = float(self.get_parameter('grid_x_max').value)
        self.grid_y_min = float(self.get_parameter('grid_y_min').value)
        self.grid_y_max = float(self.get_parameter('grid_y_max').value)
        self.robot_radius = float(self.get_parameter('robot_radius').value)

        self.step_size = float(self.get_parameter('step_size').value)
        self.goal_tolerance = float(self.get_parameter('goal_tolerance').value)
        self.max_rrt_iters = int(self.get_parameter('max_rrt_iters').value)
        self.goal_sample_rate = float(self.get_parameter('goal_sample_rate').value)
        self.min_forward_goal_x = float(self.get_parameter('min_forward_goal_x').value)

        self.reuse_path_timeout = float(self.get_parameter('reuse_path_timeout').value)
        self.max_subgoal_x = float(self.get_parameter('max_subgoal_x').value)
        self.goal_snap_radius = float(self.get_parameter('goal_snap_radius').value)

        # Internal state
        self.waypoints = self.load_waypoints(self.waypoints_csv)
        if len(self.waypoints) == 0:
            raise RuntimeError(f'No waypoints loaded from {self.waypoints_csv}')
        self.current_waypoint_idx = 0

        self.grid_cols = int(math.ceil((self.grid_x_max - self.grid_x_min) / self.grid_resolution))
        self.grid_rows = int(math.ceil((self.grid_y_max - self.grid_y_min) / self.grid_resolution))
        self.occupancy_grid = np.zeros((self.grid_rows, self.grid_cols), dtype=np.int8)
        self.inflate_cells = max(1, int(math.ceil(self.robot_radius / self.grid_resolution)))

        self.latest_scan = None
        self.current_goal_local = (1.0, 0.0)

        self.last_valid_path = None
        self.last_plan_success_time = self.get_clock().now()

        # Subscribers
        self.pose_sub = self.create_subscription(
            Odometry,
            self.pose_topic,
            self.pose_callback,
            10
        )

        self.scan_sub = self.create_subscription(
            LaserScan,
            self.scan_topic,
            self.scan_callback,
            10
        )

        # Publishers
        self.drive_pub = self.create_publisher(AckermannDriveStamped, self.drive_topic, 10)
        self.occ_grid_pub = self.create_publisher(OccupancyGrid, '/rrt/local_occupancy_grid', 10)
        self.tree_pub = self.create_publisher(Marker, '/rrt/tree', 10)
        self.path_pub = self.create_publisher(Marker, '/rrt/path', 10)
        self.goal_pub = self.create_publisher(Marker, '/rrt/goal', 10)

        self.get_logger().info(f'Loaded {len(self.waypoints)} waypoints from {self.waypoints_csv}')
        self.get_logger().info('Basic RRT node initialized.')

    # waypoint helpers

    def load_waypoints(self, csv_path):
        waypoints = []
        with open(csv_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                waypoints.append([float(row['x']), float(row['y'])])
        return np.array(waypoints)

    def get_yaw_from_quaternion(self, q):
        x = q.x
        y = q.y
        z = q.z
        w = q.w
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        return math.atan2(siny_cosp, cosy_cosp)

    def map_to_local(self, dx, dy, yaw):
        x_local = math.cos(yaw) * dx + math.sin(yaw) * dy
        y_local = -math.sin(yaw) * dx + math.cos(yaw) * dy
        return x_local, y_local

    def find_nearest_waypoint_idx(self, car_x, car_y):
        dists = np.hypot(self.waypoints[:, 0] - car_x,
                         self.waypoints[:, 1] - car_y)
        return int(np.argmin(dists))

    def find_target_waypoint(self, car_x, car_y, car_yaw):
        # Find a waypoint ahead of the car and at least lookahead_distance away.
        # Search starts from the nearest waypoint to the current pose
        n = len(self.waypoints)
        nearest_idx = self.find_nearest_waypoint_idx(car_x, car_y)

        for i in range(n):
            idx = (nearest_idx + i) % n
            wp_x, wp_y = self.waypoints[idx]

            dx = wp_x - car_x
            dy = wp_y - car_y
            dist = math.hypot(dx, dy)
            x_local, y_local = self.map_to_local(dx, dy, car_yaw)

            if dist >= self.lookahead_distance and x_local > self.min_forward_goal_x:
                self.current_waypoint_idx = idx
                return wp_x, wp_y, idx, x_local, y_local

        # fallback to nearest waypoint
        wp_x, wp_y = self.waypoints[nearest_idx]
        dx = wp_x - car_x
        dy = wp_y - car_y
        x_local, y_local = self.map_to_local(dx, dy, car_yaw)
        self.current_waypoint_idx = nearest_idx
        return wp_x, wp_y, nearest_idx, x_local, y_local

    # Occupancy grid helpers

    def local_to_grid(self, x, y):
        col = int((x - self.grid_x_min) / self.grid_resolution)
        row = int((y - self.grid_y_min) / self.grid_resolution)
        if row < 0 or row >= self.grid_rows or col < 0 or col >= self.grid_cols:
            return None
        return row, col

    def is_free(self, x, y):
        idx = self.local_to_grid(x, y)
        if idx is None:
            return False
        row, col = idx
        return self.occupancy_grid[row, col] == 0

    def mark_occupied(self, x, y):
        idx = self.local_to_grid(x, y)
        if idx is None:
            return
        row, col = idx

        r0 = max(0, row - self.inflate_cells)
        r1 = min(self.grid_rows - 1, row + self.inflate_cells)
        c0 = max(0, col - self.inflate_cells)
        c1 = min(self.grid_cols - 1, col + self.inflate_cells)

        self.occupancy_grid[r0:r1 + 1, c0:c1 + 1] = 1

    def publish_occupancy_grid(self):
        msg = OccupancyGrid()
        msg.header.frame_id = self.local_frame
        msg.header.stamp = self.get_clock().now().to_msg()

        msg.info.resolution = self.grid_resolution
        msg.info.width = self.grid_cols
        msg.info.height = self.grid_rows
        msg.info.origin.position.x = self.grid_x_min
        msg.info.origin.position.y = self.grid_y_min
        msg.info.origin.position.z = 0.0
        msg.info.origin.orientation.w = 1.0

        grid_data = np.where(self.occupancy_grid == 1, 100, 0).astype(np.int8)
        msg.data = grid_data.flatten().tolist()
        self.occ_grid_pub.publish(msg)

    def scan_callback(self, scan_msg):
        # Build a local binary occupancy grid from the current laser scan.
        self.latest_scan = scan_msg
        self.occupancy_grid.fill(0)

        angle = scan_msg.angle_min
        for r in scan_msg.ranges:
            valid = (
                np.isfinite(r)
                and r >= scan_msg.range_min
                and r <= scan_msg.range_max
            )

            if valid:
                x = r * math.cos(angle)
                y = r * math.sin(angle)

                if self.grid_x_min <= x <= self.grid_x_max and self.grid_y_min <= y <= self.grid_y_max:
                    self.mark_occupied(x, y)

            angle += scan_msg.angle_increment

        self.publish_occupancy_grid()

    # RRT methods

    def sample(self):
        gx, gy = self.current_goal_local
        goal_side_positive = gy >= 0  # True = goal is to the left (positive y)

        for _ in range(150):  
            r = np.random.rand()

            # Goal bias
            if r < self.goal_sample_rate:
                x, y = gx, gy

            # Primary side: same lateral side as the goal 
            elif r < 0.55:
                x = np.random.uniform(0.2, self.grid_x_max)
                if goal_side_positive:
                    y = np.random.uniform(0.0, self.grid_y_max)
                else:
                    y = np.random.uniform(self.grid_y_min, 0.0)

            # Secondary side: opposite side, still needed to find routes that
            # loop around obstacles
            elif r < 0.85:
                x = np.random.uniform(0.2, self.grid_x_max)
                if goal_side_positive:
                    y = np.random.uniform(self.grid_y_min, 0.0)
                else:
                    y = np.random.uniform(0.0, self.grid_y_max)

            # Full-box exploration (15% weight)
            else:
                x = np.random.uniform(0.0, self.grid_x_max)
                y = np.random.uniform(self.grid_y_min, self.grid_y_max)

            if self.is_free(x, y):
                return (x, y)

        return (gx, gy)

    def nearest(self, tree, sampled_point):
        sx, sy = sampled_point
        dists = [(node.x - sx) ** 2 + (node.y - sy) ** 2 for node in tree]
        return int(np.argmin(dists))

    def steer(self, nearest_node, sampled_point):
        sx, sy = sampled_point
        dx = sx - nearest_node.x
        dy = sy - nearest_node.y
        dist = math.hypot(dx, dy)

        if dist < 1e-6:
            return None

        step = min(self.step_size, dist)
        theta = math.atan2(dy, dx)

        new_x = nearest_node.x + step * math.cos(theta)
        new_y = nearest_node.y + step * math.sin(theta)

        return TreeNode(x=new_x, y=new_y, parent=nearest_node, cost=nearest_node.cost + step)

    def check_collision(self, nearest_node, new_node):
        dx = new_node.x - nearest_node.x
        dy = new_node.y - nearest_node.y
        dist = math.hypot(dx, dy)

        if dist < 1e-9:
            return self.is_free(new_node.x, new_node.y)

        num_steps = max(2, int(dist / (self.grid_resolution * 0.5)))

        for i in range(num_steps + 1):
            t = i / num_steps
            x = nearest_node.x + t * dx
            y = nearest_node.y + t * dy

            if not self.is_free(x, y):
                return False

        return True

    def is_goal(self, latest_added_node, goal_x, goal_y):
        dist = math.hypot(latest_added_node.x - goal_x, latest_added_node.y - goal_y)
        return dist < self.goal_tolerance

    def find_path(self, latest_added_node):
        path = []
        node = latest_added_node
        while node is not None:
            path.append(node)
            node = node.parent
        path.reverse()
        return path

    def snap_goal_to_free(self, goal_x, goal_y):
        if self.is_free(goal_x, goal_y):
            return goal_x, goal_y

        step = self.grid_resolution
        num_steps = int(self.goal_snap_radius / step)

        best = None
        best_dist = float('inf')

        for dr in range(-num_steps, num_steps + 1):
            for dc in range(-num_steps, num_steps + 1):
                cx = goal_x + dc * step
                cy = goal_y + dr * step

                # Must still be a useful forward goal
                if cx < self.min_forward_goal_x:
                    continue

                if self.is_free(cx, cy):
                    dist = math.hypot(cx - goal_x, cy - goal_y)
                    if dist < best_dist:
                        best_dist = dist
                        best = (cx, cy)

        if best is not None:
            self.get_logger().warn(
                f'Goal snapped: ({goal_x:.2f}, {goal_y:.2f}) -> '
                f'({best[0]:.2f}, {best[1]:.2f})'
            )
            return best

        # Could not find a free neighbour — return original and let the caller
        # decide
        self.get_logger().warn(
            f'Goal snap failed for ({goal_x:.2f}, {goal_y:.2f}) '
            f'within radius {self.goal_snap_radius:.2f} — no free cell found.'
        )
        return goal_x, goal_y

    def plan_rrt(self, goal_x, goal_y):
        """
        Run RRT from (0, 0) in the local frame to (goal_x, goal_y).
        """
        if not self.is_free(goal_x, goal_y):
            self.get_logger().warn(
                f'plan_rrt: goal ({goal_x:.2f}, {goal_y:.2f}) is occupied — skipping.'
            )
            return [], None

        start = TreeNode(x=0.0, y=0.0, parent=None, cost=0.0, is_root=True)

        # direct line
        goal_node = TreeNode(
            x=goal_x, y=goal_y,
            parent=start,
            cost=math.hypot(goal_x, goal_y)
        )
        if self.check_collision(start, goal_node):
            return [start, goal_node], [start, goal_node]

        # Full RRT expansion
        tree = [start]
        path = None

        for _ in range(self.max_rrt_iters):
            sampled_point = self.sample()
            nearest_idx = self.nearest(tree, sampled_point)
            nearest_node = tree[nearest_idx]

            new_node = self.steer(nearest_node, sampled_point)
            if new_node is None:
                continue

            if not self.check_collision(nearest_node, new_node):
                continue

            tree.append(new_node)

            if self.is_goal(new_node, goal_x, goal_y):
                goal_node = TreeNode(x=goal_x, y=goal_y, parent=new_node, cost=new_node.cost)
                if self.check_collision(new_node, goal_node):
                    tree.append(goal_node)
                    path = self.find_path(goal_node)
                    break

        return tree, path

    # Tracking helpers

    def select_path_target(self, path):
        for node in path:
            d = math.hypot(node.x, node.y)
            if d >= self.path_lookahead:
                return node
        return path[-1]

    def publish_drive(self, steering_angle, speed):
        msg = AckermannDriveStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.drive.steering_angle = float(steering_angle)
        msg.drive.speed = float(speed)
        self.drive_pub.publish(msg)

    def stop_vehicle(self):
        self.publish_drive(0.0, 0.0)

    def follow_target_point(self, target_x, target_y, speed):
        """
        Pure-pursuit-style steering using a target point in vehicle frame.
        """
        L = math.hypot(target_x, target_y)
        if L < 1e-6:
            self.stop_vehicle()
            return

        curvature = 2.0 * target_y / (L * L)
        steering_angle = math.atan(self.wheelbase * curvature)

        steering_angle = max(
            -self.max_steering_angle,
            min(self.max_steering_angle, steering_angle)
        )

        self.publish_drive(steering_angle, speed)

    # Visualization

    def publish_goal_marker(self, x, y):
        marker = Marker()
        marker.header.frame_id = self.local_frame
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = 'rrt_goal'
        marker.id = 0
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD

        marker.pose.position.x = float(x)
        marker.pose.position.y = float(y)
        marker.pose.position.z = 0.0
        marker.pose.orientation.w = 1.0

        marker.scale.x = 0.22
        marker.scale.y = 0.22
        marker.scale.z = 0.22

        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0
        marker.color.a = 1.0

        self.goal_pub.publish(marker)

    def publish_tree_marker(self, tree):
        marker = Marker()
        marker.header.frame_id = self.local_frame
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = 'rrt_tree'
        marker.id = 0
        marker.type = Marker.LINE_LIST
        marker.action = Marker.ADD

        marker.pose.orientation.w = 1.0
        marker.scale.x = 0.03

        marker.color.r = 0.2
        marker.color.g = 0.6
        marker.color.b = 1.0
        marker.color.a = 1.0

        for node in tree:
            if node.parent is None:
                continue

            p1 = Point()
            p1.x = float(node.parent.x)
            p1.y = float(node.parent.y)
            p1.z = 0.0

            p2 = Point()
            p2.x = float(node.x)
            p2.y = float(node.y)
            p2.z = 0.0

            marker.points.append(p1)
            marker.points.append(p2)

        self.tree_pub.publish(marker)

    def publish_path_marker(self, path):
        marker = Marker()
        marker.header.frame_id = self.local_frame
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = 'rrt_path'
        marker.id = 0
        marker.type = Marker.LINE_STRIP
        marker.action = Marker.ADD

        marker.pose.orientation.w = 1.0
        marker.scale.x = 0.08

        marker.color.r = 0.0
        marker.color.g = 1.0
        marker.color.b = 0.2
        marker.color.a = 1.0

        for node in path:
            p = Point()
            p.x = float(node.x)
            p.y = float(node.y)
            p.z = 0.0
            marker.points.append(p)

        self.path_pub.publish(marker)

    # Main callback

    def pose_callback(self, pose_msg):
        """
        Main RRT loop:
        1) choose forward waypoint from global track
        2) transform goal into local frame
        3) clip local goal to shorter subgoal
        4) snap goal out of obstacles
        5) run local RRT with fast-fail / fast-succeed guards 
        6) follow resulting path with pure-pursuit-style steering
        """
        if self.latest_scan is None:
            return

        car_x = pose_msg.pose.pose.position.x
        car_y = pose_msg.pose.pose.position.y
        car_yaw = self.get_yaw_from_quaternion(pose_msg.pose.pose.orientation)

        goal_x_map, goal_y_map, _, goal_local_x, goal_local_y = self.find_target_waypoint(
            car_x, car_y, car_yaw
        )

        # Clip goal into planning box
        goal_local_x = float(np.clip(goal_local_x, 0.0, self.grid_x_max - 0.05))
        goal_local_y = float(np.clip(goal_local_y, self.grid_y_min + 0.05, self.grid_y_max - 0.05))

        # Clip local goal to a closer subgoal so planner solves a smaller problem
        if goal_local_x > self.max_subgoal_x:
            scale = self.max_subgoal_x / max(goal_local_x, 1e-6)
            goal_local_x *= scale
            goal_local_y *= scale

        goal_local_x, goal_local_y = self.snap_goal_to_free(goal_local_x, goal_local_y)

        self.current_goal_local = (goal_local_x, goal_local_y)
        self.publish_goal_marker(goal_local_x, goal_local_y)

        # If the goal is not meaningfully ahead, do nothing dangerous
        if goal_local_x < self.min_forward_goal_x:
            self.stop_vehicle()
            self.publish_tree_marker([])
            self.publish_path_marker([])
            return

        tree, path = self.plan_rrt(goal_local_x, goal_local_y)

        # Visualize tree (may be empty on fast-fail)
        self.publish_tree_marker(tree)

        # If no path found, reuse last valid path briefly before stopping
        if path is None:
            now = self.get_clock().now()
            dt = (now - self.last_plan_success_time).nanoseconds * 1e-9

            if self.last_valid_path is not None and dt < self.reuse_path_timeout:
                path = self.last_valid_path
            else:
                self.publish_path_marker([])
                self.stop_vehicle()
                return
        else:
            self.last_valid_path = path
            self.last_plan_success_time = self.get_clock().now()

        self.publish_path_marker(path)

        # Track the path
        target_node = self.select_path_target(path)
        self.follow_target_point(target_node.x, target_node.y, self.speed)


def main(args=None):
    rclpy.init(args=args)
    print("RRT Initialized")
    rrt_node = RRT()
    rclpy.spin(rrt_node)

    rrt_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()