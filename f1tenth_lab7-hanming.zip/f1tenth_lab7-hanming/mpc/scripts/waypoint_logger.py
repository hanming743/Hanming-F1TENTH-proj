#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
import numpy as np
import csv

class WaypointLogger(Node):
    def __init__(self):
        super().__init__('waypoint_logger')
        self.sub = self.create_subscription(
            Odometry,
            '/ego_racecar/odom',
            self.odom_callback,
            10
        )
        self.waypoints = []
        self.last_x = None
        self.last_y = None
        self.min_dist = 0.1  # 每隔0.1m记录一个点
        self.get_logger().info('Waypoint logger started. Drive the car!')

    def odom_callback(self, msg):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        v = msg.twist.twist.linear.x

        qx = msg.pose.pose.orientation.x
        qy = msg.pose.pose.orientation.y
        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w

        # 计算yaw
        import math
        siny_cosp = 2.0 * (qw * qz + qx * qy)
        cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
        yaw = math.atan2(siny_cosp, cosy_cosp)

        # 只在移动了足够距离后记录
        if self.last_x is None or \
           math.sqrt((x - self.last_x)**2 + (y - self.last_y)**2) >= self.min_dist:
            self.waypoints.append([x, y, yaw, max(abs(v), 1.0)])
            self.last_x = x
            self.last_y = y
            self.get_logger().info(f'Recorded point {len(self.waypoints)}: x={x:.2f}, y={y:.2f}')

    def save_waypoints(self):
        with open('waypoints.csv', 'w', newline='') as f:
            writer = csv.writer(f)
            for wp in self.waypoints:
                writer.writerow(wp)
        self.get_logger().info(f'Saved {len(self.waypoints)} waypoints to waypoints.csv')

def main(args=None):
    rclpy.init(args=args)
    logger = WaypointLogger()
    try:
        rclpy.spin(logger)
    except KeyboardInterrupt:
        logger.save_waypoints()  # Ctrl+C时保存
    logger.destroy_node()
    rclpy.shutdown()

main()